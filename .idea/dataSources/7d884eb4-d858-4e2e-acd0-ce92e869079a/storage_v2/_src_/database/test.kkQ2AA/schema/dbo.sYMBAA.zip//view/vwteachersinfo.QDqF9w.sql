CREATE VIEW vwTeachersInfo AS
-- -- создали представление

SELECT
  -- не обязательно делать выборку, можно все распечатать
  teachers.[Name],
  teachers.[LastName],
  lessons.[NameLesson]
  FROM teachers
  JOIN TeachersInfo ON teachers.id = TeachersInfo.teacher
  JOIN Lessons ON TeachersInfo.lesson = lessons.id
go

