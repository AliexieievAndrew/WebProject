CREATE VIEW vwTeachersSalaryInfo AS
  -- -- создали представление

SELECT
  teachers.[Name],
  teachers.[LastName],
  lessons.[NameLesson],
  teachersSalary.[teacherSalary]
FROM teachers
JOIN TeachersInfoTest ON TeachersInfoTest.[name] = teachers.[id]
JOIN lessons ON TeachersInfoTest.[lesson] = lessons.[id]
JOIN teachersSalary ON teachersSalary.[teacherPosition] = lessons.[id]
go

