CREATE PROCEDURE getTeacherByLastName
    @lastName NVARCHAR(30)
AS
  SELECT * FROM teachers where LastName LIKE '%' + @lastName + '%'
go

