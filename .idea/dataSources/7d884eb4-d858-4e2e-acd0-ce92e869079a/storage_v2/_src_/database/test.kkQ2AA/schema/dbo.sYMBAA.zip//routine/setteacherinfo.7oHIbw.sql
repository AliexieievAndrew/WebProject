CREATE PROCEDURE setTeacherInfo @idTeacher BIGINT, @idLesson BIGINT AS INSERT INTO TeachersInfo VALUES (@idTeacher,@idLesson);
go

