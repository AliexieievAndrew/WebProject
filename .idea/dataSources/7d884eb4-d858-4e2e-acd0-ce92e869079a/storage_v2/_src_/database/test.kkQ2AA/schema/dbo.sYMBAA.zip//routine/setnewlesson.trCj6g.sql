CREATE PROCEDURE setNewLesson @name NVARCHAR(30), @desc NVARCHAR(30) AS INSERT INTO lessons VALUES (@name,@desc);
go

