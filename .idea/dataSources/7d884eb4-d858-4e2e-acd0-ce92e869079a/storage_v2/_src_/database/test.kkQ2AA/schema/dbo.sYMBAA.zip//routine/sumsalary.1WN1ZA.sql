CREATE PROCEDURE sumSalary
  @name NVARCHAR(30)
  AS
  SELECT
    vwTeachersSalaryInfo.[LastName],
    sum(vwTeachersSalaryInfo.[teacherSalary]) AS totalSalary
  FROM vwTeachersSalaryInfo
  WHERE vwTeachersSalaryInfo.[LastName] LIKE '%' + @name + '%'
  GROUP BY vwTeachersSalaryInfo.[LastName];
go

